package com.example.semana09firebase.model

data class CourseModel(
    val description: String ="",
    val score: String = "",
    val imageUrl: String =""
)
