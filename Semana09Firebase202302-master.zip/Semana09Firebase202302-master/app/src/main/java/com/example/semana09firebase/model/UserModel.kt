package com.example.semana09firebase.model

data class UserModel(
    val email: String="",
    val password: String = "",
    val fullName: String = "",
    val country: String= "",
    val UID: String= ""
)
