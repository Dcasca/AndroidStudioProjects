package dev.luischang.firebaseuesan2021.ui.fragments.model

data class MascotaModel(
    var nommascota:String,
    var fechaperdida: String,
    var urlimagen:String,
    var lugar:String,
    var contacto:String

)
