package dev.luischang.firebaseuesan2021.ui.fragments.model

data class CourseModel(
    val description: String="",
    val score:String=""
)
